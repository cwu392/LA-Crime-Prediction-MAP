"""Default configuration for Flask application"""
# Debugging features on in Flask
DEBUG = True
SQLALCHEMY_TRACK_MODIFICATIONS = False