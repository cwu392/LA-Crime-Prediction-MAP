"""Define models for ORM"""
from ..init_db import INCIDENTS_TABLE
from flask_sqlalchemy import SQLAlchemy
db = SQLAlchemy()
